﻿namespace ClassLibraryMA
{
    public class Class1
    {
      public double div(double x,double y) 
        {
            return x/y;
        } 
    }
}